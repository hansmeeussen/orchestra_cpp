#pragma once

#include <string>

namespace orchestracpp
{

	class OObjectPieceOfText
	{
	public:
		std::string text;
        
		OObjectPieceOfText(const std::string &text);
       // virtual ~OObjectPieceOfText(){};

    };
}
