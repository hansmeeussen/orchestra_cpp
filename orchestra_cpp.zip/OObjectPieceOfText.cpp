#include "OObjectPieceOfText.h"

namespace orchestracpp
{

	OObjectPieceOfText::OObjectPieceOfText(const std::string &text)
	{
		this->text = text;
	}

}
